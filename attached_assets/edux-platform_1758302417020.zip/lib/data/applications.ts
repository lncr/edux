export interface Application {
  id: string
  universityId: string
  universityName: string
  targetProgram: "Bachelor" | "Master" | "PhD"
  status: "Submitted" | "Under Review" | "Accepted" | "Rejected" | "Waitlisted"
  dateSubmitted: string
  essay: string
  highestEducation: string
  recommendationLetter?: string
  educationDocument?: string
}

// Mock data for applications
export const applications: Application[] = [
  {
    id: "1",
    universityId: "1",
    universityName: "Harvard University",
    targetProgram: "Master",
    status: "Under Review",
    dateSubmitted: "2024-01-15",
    essay: "My passion for computer science began...",
    highestEducation: "Bachelor",
    recommendationLetter: "recommendation-letter-1.pdf",
    educationDocument: "bachelor-degree.pdf",
  },
  {
    id: "2",
    universityId: "2",
    universityName: "Stanford University",
    targetProgram: "PhD",
    status: "Submitted",
    dateSubmitted: "2024-01-20",
    essay: "Research has always been my calling...",
    highestEducation: "Master",
    recommendationLetter: "recommendation-letter-2.pdf",
    educationDocument: "master-degree.pdf",
  },
]

export function getApplicationsByUser(): Application[] {
  // In a real app, this would filter by user ID
  return applications
}

export function getApplicationById(id: string): Application | undefined {
  return applications.find((app) => app.id === id)
}
