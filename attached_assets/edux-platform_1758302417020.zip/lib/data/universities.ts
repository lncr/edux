export interface University {
  id: string
  name: string
  description: string
  image: string
  thumbnail: string
  location: string
  faculties: string[]
  divisions: string[]
  gallery: string[]
  established: number
  students: number
  ranking?: number
}

// Mock data for universities
export const universities: University[] = [
  {
    id: "1",
    name: "Harvard University",
    description:
      "Harvard University is a private Ivy League research university in Cambridge, Massachusetts. Established in 1636, Harvard is the oldest institution of higher education in the United States and among the most prestigious in the world.",
    image: "/harvard-university-campus-aerial-view.jpg",
    thumbnail: "/harvard-university-building.jpg",
    location: "Cambridge, Massachusetts, USA",
    faculties: [
      "Faculty of Arts and Sciences",
      "Harvard Medical School",
      "Harvard Business School",
      "Harvard Law School",
      "School of Engineering and Applied Sciences",
    ],
    divisions: ["Undergraduate College", "Graduate School of Arts and Sciences", "Professional Schools"],
    gallery: [
      "/harvard-university-library.jpg",
      "/harvard-university-dormitory.jpg",
      "/harvard-university-lecture-hall.jpg",
      "/harvard-university-campus-quad.jpg",
    ],
    established: 1636,
    students: 23000,
    ranking: 1,
  },
  {
    id: "2",
    name: "Stanford University",
    description:
      "Stanford University is a private research university in Stanford, California. Known for its academic strength, wealth, proximity to Silicon Valley, and ranking as one of the world's top universities.",
    image: "/stanford-university-campus-with-palm-trees.jpg",
    thumbnail: "/stanford-university-hoover-tower.jpg",
    location: "Stanford, California, USA",
    faculties: [
      "School of Engineering",
      "School of Medicine",
      "Graduate School of Business",
      "School of Law",
      "School of Education",
    ],
    divisions: ["Undergraduate Program", "Graduate Programs", "Professional Schools"],
    gallery: [
      "/stanford-university-memorial-church.jpg",
      "/stanford-university-engineering-building.jpg",
      "/stanford-university-student-center.jpg",
      "/stanford-university-athletics-facility.jpg",
    ],
    established: 1885,
    students: 17000,
    ranking: 2,
  },
  {
    id: "3",
    name: "MIT",
    description:
      "The Massachusetts Institute of Technology is a private land-grant research university in Cambridge, Massachusetts. MIT has played a key role in the development of modern technology and science.",
    image: "/mit-campus-with-modern-buildings.jpg",
    thumbnail: "/mit-great-dome-building.jpg",
    location: "Cambridge, Massachusetts, USA",
    faculties: [
      "School of Engineering",
      "School of Science",
      "MIT Sloan School of Management",
      "School of Architecture and Planning",
      "School of Humanities, Arts, and Social Sciences",
    ],
    divisions: ["Undergraduate Program", "Graduate School", "Professional Education"],
    gallery: [
      "/mit-stata-center-modern-architecture.jpg",
      "/placeholder.svg?height=300&width=400",
      "/placeholder.svg?height=300&width=400",
      "/placeholder.svg?height=300&width=400",
    ],
    established: 1861,
    students: 11500,
    ranking: 3,
  },
  {
    id: "4",
    name: "University of Oxford",
    description:
      "The University of Oxford is a collegiate research university in Oxford, England. There is evidence of teaching as early as 1096, making it the oldest university in the English-speaking world.",
    image: "/placeholder.svg?height=400&width=800",
    thumbnail: "/placeholder.svg?height=200&width=300",
    location: "Oxford, England, UK",
    faculties: [
      "Humanities Division",
      "Mathematical, Physical and Life Sciences Division",
      "Medical Sciences Division",
      "Social Sciences Division",
    ],
    divisions: ["Undergraduate Colleges", "Graduate Schools", "Continuing Education"],
    gallery: [
      "/placeholder.svg?height=300&width=400",
      "/placeholder.svg?height=300&width=400",
      "/placeholder.svg?height=300&width=400",
      "/placeholder.svg?height=300&width=400",
    ],
    established: 1096,
    students: 24000,
    ranking: 4,
  },
  {
    id: "5",
    name: "University of Cambridge",
    description:
      "The University of Cambridge is a collegiate research university in Cambridge, United Kingdom. Founded in 1209, Cambridge is the second-oldest university in the English-speaking world.",
    image: "/placeholder.svg?height=400&width=800",
    thumbnail: "/placeholder.svg?height=200&width=300",
    location: "Cambridge, England, UK",
    faculties: [
      "Arts and Humanities",
      "Biological Sciences",
      "Clinical Medicine",
      "Humanities and Social Sciences",
      "Physical Sciences",
      "Technology",
    ],
    divisions: ["Undergraduate Colleges", "Graduate School", "Research Institutes"],
    gallery: [
      "/placeholder.svg?height=300&width=400",
      "/placeholder.svg?height=300&width=400",
      "/placeholder.svg?height=300&width=400",
      "/placeholder.svg?height=300&width=400",
    ],
    established: 1209,
    students: 23000,
    ranking: 5,
  },
  {
    id: "6",
    name: "University of Tokyo",
    description:
      "The University of Tokyo is a public research university in Bunkyō, Tokyo, Japan. Established in 1877, it was the first imperial university and is considered the most prestigious university in Japan.",
    image: "/placeholder.svg?height=400&width=800",
    thumbnail: "/placeholder.svg?height=200&width=300",
    location: "Tokyo, Japan",
    faculties: [
      "Faculty of Law",
      "Faculty of Medicine",
      "Faculty of Engineering",
      "Faculty of Letters",
      "Faculty of Science",
      "Faculty of Agriculture",
      "Faculty of Economics",
    ],
    divisions: ["Undergraduate Schools", "Graduate Schools", "Research Institutes"],
    gallery: [
      "/placeholder.svg?height=300&width=400",
      "/placeholder.svg?height=300&width=400",
      "/placeholder.svg?height=300&width=400",
      "/placeholder.svg?height=300&width=400",
    ],
    established: 1877,
    students: 28000,
    ranking: 6,
  },
]

export function getUniversityById(id: string): University | undefined {
  return universities.find((uni) => uni.id === id)
}

export function searchUniversities(query: string): University[] {
  if (!query) return universities

  const lowercaseQuery = query.toLowerCase()
  return universities.filter(
    (uni) =>
      uni.name.toLowerCase().includes(lowercaseQuery) ||
      uni.location.toLowerCase().includes(lowercaseQuery) ||
      uni.faculties.some((faculty) => faculty.toLowerCase().includes(lowercaseQuery)),
  )
}
